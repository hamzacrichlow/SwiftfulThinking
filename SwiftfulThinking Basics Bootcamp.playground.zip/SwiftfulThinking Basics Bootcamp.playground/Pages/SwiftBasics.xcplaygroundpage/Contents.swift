
import Foundation

var greeting = "Hello, playground"

//Left panel is called the navigator and it holds all of the files. When you build an application you have tons of files in this column organizes to your likings. A full App is for example 100-1000 files that work well together.

//On the right side is the output on playgrounds. Runingn code in swift runs from the top to the bottom. Click the play button to get it to run. In the real version of building an appp it would be the canvas showcasing our app.

//Printing to the console. By calling the function print.

print(greeting)

 // At the bottom is the console and it will print out whatever we say to print. In most apps we dont have the right side so we rely on the console to visualize whats happenigin in our app.



import Foundation


//Type String refers to regular text and is always in quotation marks.

// In swift if you hoold the option button on the keyboard you can click the variable and see what it is declared as.

let myFirsItem = "Hello World"
 


//Refrence previously created objects
let myTitle = myFirsItem


//Boolean (aka Bool) is true or false
let mySecondItem: Bool = true
let myThirdItem: Bool = false

//Swift is a type-safe language
let myFourthItem: Bool = true
